//! exec-core binary: NATS ile dış dünyaya bağlanır, Engine'i tek bir task içinde
//! sıralı çalıştırır (determinizm), olayları subject'lere yayınlar.
//!
//! Giriş  : exec.order.submit | exec.order.cancel | exec.broker.ack | exec.broker.reject
//!          exec.broker.fill | exec.broker.cancelled | md.tick.<SYMBOL>
//! Çıkış  : exec.order.state | exec.broker.send | exec.broker.cancel | exec.risk.violation | exec.order.rejected

use exec_core::{engine::BasicRisk, Command, Engine, Event};
use futures::StreamExt;
use rust_decimal_macros::dec;
use std::sync::Arc;
use tokio::sync::{mpsc, Mutex};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt().with_env_filter(tracing_subscriber::EnvFilter::from_default_env()).init();
    let url = std::env::var("NATS_URL").unwrap_or_else(|_| "nats://localhost:4222".into());
    let nc = async_nats::connect(&url).await?;
    tracing::info!(%url, "exec-core connected");

    let engine = Arc::new(Mutex::new(Engine::new(Box::new(BasicRisk { max_qty: dec!(1_000_000) }))));
    let (tx, mut rx) = mpsc::channel::<Command>(4096);

    // Tüm subject'leri dinle, Command'a çevir, tek kanala akıt (sıralı işleme)
    let subjects = [
        "exec.order.submit", "exec.order.cancel", "exec.broker.ack", "exec.broker.reject",
        "exec.broker.fill", "exec.broker.cancelled", "md.tick.*",
    ];
    for s in subjects {
        let mut sub = nc.subscribe(s).await?;
        let tx = tx.clone();
        tokio::spawn(async move {
            while let Some(m) = sub.next().await {
                match parse(&m.subject, &m.payload) {
                    Ok(cmd) => { let _ = tx.send(cmd).await; }
                    Err(e) => tracing::warn!(subject = %m.subject, "bad payload: {e}"),
                }
            }
        });
    }

    // Tek tüketici: Engine'i sıralı çalıştır, olayları yayınla
    while let Some(cmd) = rx.recv().await {
        let events = engine.lock().await.apply(cmd);
        for ev in events {
            let (subject, payload) = route(&ev);
            if let Err(e) = nc.publish(subject, payload.into()).await {
                tracing::error!("publish failed: {e}");
            }
        }
    }
    Ok(())
}

fn parse(subject: &str, payload: &[u8]) -> anyhow::Result<Command> {
    Ok(match subject {
        "exec.order.submit" => Command::Submit(serde_json::from_slice(payload)?),
        "exec.order.cancel" => {
            #[derive(serde::Deserialize)]
            struct C { order_id: uuid::Uuid, leg: Option<usize> }
            let c: C = serde_json::from_slice(payload)?;
            Command::Cancel { order_id: c.order_id, leg: c.leg }
        }
        "exec.broker.ack" => {
            #[derive(serde::Deserialize)]
            struct A { ems_order_id: String, broker_order_id: String }
            let a: A = serde_json::from_slice(payload)?;
            Command::BrokerAck { ems_order_id: a.ems_order_id, broker_order_id: a.broker_order_id }
        }
        "exec.broker.reject" => {
            #[derive(serde::Deserialize)]
            struct R { ems_order_id: String, reason: String }
            let r: R = serde_json::from_slice(payload)?;
            Command::BrokerReject { ems_order_id: r.ems_order_id, reason: r.reason }
        }
        "exec.broker.fill" => Command::BrokerFill(serde_json::from_slice(payload)?),
        "exec.broker.cancelled" => {
            #[derive(serde::Deserialize)]
            struct X { ems_order_id: String }
            let x: X = serde_json::from_slice(payload)?;
            Command::BrokerCancelled { ems_order_id: x.ems_order_id }
        }
        s if s.starts_with("md.tick.") => Command::Tick(serde_json::from_slice(payload)?),
        s => anyhow::bail!("unknown subject {s}"),
    })
}

fn route(ev: &Event) -> (&'static str, Vec<u8>) {
    let subject = match ev {
        Event::StateChanged { .. } => "exec.order.state",
        Event::SendToBroker(_) => "exec.broker.send",
        Event::CancelAtBroker { .. } => "exec.broker.cancel",
        Event::RiskViolation { .. } => "exec.risk.violation",
        Event::Rejected { .. } => "exec.order.rejected",
    };
    (subject, serde_json::to_vec(ev).expect("serialize event"))
}
