//! Engine: saf, deterministik emir orkestrasyonu.
//! Komut alır → durum günceller → olay listesi döner. I/O yok.

use crate::events::{Command, Event};
use crate::order::*;
use crate::state_machine::Status;
use crate::trigger::TriggerRule;
use rust_decimal::Decimal;
use std::collections::HashMap;
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct LegState {
    pub leg: Leg,
    pub status: Status,
    pub filled: Decimal,
    pub broker_order_id: Option<String>,
    pub rule: Option<TriggerRule>,
}

#[derive(Debug, Clone)]
pub struct TreeState {
    pub tree: OrderTree,
    pub legs: Vec<LegState>,
}

/// Pre-trade risk kancası: motor risk politikası bilmez, dışarıdan verilir.
pub trait RiskPolicy: Send {
    fn check(&self, tree: &OrderTree, leg: &Leg) -> Result<(), (String, String)>; // (rule, detail)
}

pub struct NoRisk;
impl RiskPolicy for NoRisk {
    fn check(&self, _: &OrderTree, _: &Leg) -> Result<(), (String, String)> {
        Ok(())
    }
}

/// Basit limitler: max qty ve fat-finger (last'a göre sapma) — tenant bazlı config sonradan
pub struct BasicRisk {
    pub max_qty: Decimal,
}
impl RiskPolicy for BasicRisk {
    fn check(&self, _: &OrderTree, leg: &Leg) -> Result<(), (String, String)> {
        if leg.qty > self.max_qty {
            return Err(("MAX_QTY".into(), format!("{} > {}", leg.qty, self.max_qty)));
        }
        Ok(())
    }
}

pub struct Engine {
    trees: HashMap<Uuid, TreeState>,
    by_ems_id: HashMap<String, (Uuid, usize)>,
    last_price: HashMap<String, Decimal>,
    risk: Box<dyn RiskPolicy>,
}

impl Default for Engine {
    fn default() -> Self {
        Self::new(Box::new(NoRisk))
    }
}

impl Engine {
    pub fn new(risk: Box<dyn RiskPolicy>) -> Self {
        Self { trees: HashMap::new(), by_ems_id: HashMap::new(), last_price: HashMap::new(), risk }
    }

    pub fn tree(&self, id: &Uuid) -> Option<&TreeState> {
        self.trees.get(id)
    }

    pub fn apply(&mut self, cmd: Command) -> Vec<Event> {
        let mut ev = Vec::new();
        match cmd {
            Command::Submit(tree) => self.submit(tree, &mut ev),
            Command::Cancel { order_id, leg } => self.cancel(order_id, leg, &mut ev),
            Command::BrokerAck { ems_order_id, broker_order_id } => {
                if let Some((id, i)) = self.lookup(&ems_order_id) {
                    self.set_broker_id(id, i, broker_order_id);
                    self.transition(id, i, Status::Working, None, &mut ev);
                }
            }
            Command::BrokerReject { ems_order_id, reason } => {
                if let Some((id, i)) = self.lookup(&ems_order_id) {
                    self.transition(id, i, Status::Rejected, Some(reason), &mut ev);
                }
            }
            Command::BrokerFill(f) => self.on_fill(f, &mut ev),
            Command::BrokerCancelled { ems_order_id } => {
                if let Some((id, i)) = self.lookup(&ems_order_id) {
                    self.transition(id, i, Status::Cancelled, None, &mut ev);
                }
            }
            Command::Tick(t) => self.on_tick(t, &mut ev),
        }
        ev
    }

    // ---------------- submit ----------------
    fn submit(&mut self, tree: OrderTree, ev: &mut Vec<Event>) {
        if let Err(reason) = tree.validate() {
            ev.push(Event::Rejected { order_id: tree.id, reason });
            return;
        }
        let id = tree.id;
        let legs = tree
            .legs
            .iter()
            .map(|l| LegState { leg: l.clone(), status: Status::Draft, filled: Decimal::ZERO, broker_order_id: None, rule: None })
            .collect();
        self.trees.insert(id, TreeState { tree, legs });
        let n = self.trees[&id].legs.len();
        for i in 0..n {
            let ems = format!("{id}:{i}");
            self.by_ems_id.insert(ems, (id, i));
            if self.trees[&id].tree.is_root(i) {
                self.activate(id, i, ev);
            } else {
                self.transition(id, i, Status::PendingTrigger, Some("waiting parent".into()), ev);
            }
        }
    }

    /// Leg'i canlandır: risk → (trigger bekle | broker'a gönder)
    fn activate(&mut self, id: Uuid, i: usize, ev: &mut Vec<Event>) {
        let ts = &self.trees[&id];
        let leg = ts.legs[i].leg.clone();
        let tree = ts.tree.clone();

        self.transition(id, i, Status::PendingRisk, None, ev);
        if let Err((rule, detail)) = self.risk.check(&tree, &leg) {
            ev.push(Event::RiskViolation { order_id: id, leg: i, rule: rule.clone(), detail: detail.clone() });
            self.transition(id, i, Status::Rejected, Some(rule), ev);
            return;
        }

        if leg.needs_trigger() {
            let reference = self.last_price.get(&leg.symbol).copied();
            let rule = TriggerRule::from_leg(&leg, reference);
            self.trees.get_mut(&id).unwrap().legs[i].rule = rule;
            self.transition(id, i, Status::PendingTrigger, Some("waiting trigger".into()), ev);
            return;
        }
        self.send(id, i, leg.price, leg.native_type, ev);
    }

    fn send(&mut self, id: Uuid, i: usize, price: Option<Decimal>, native_type: NativeType, ev: &mut Vec<Event>) {
        self.transition(id, i, Status::Sending, None, ev);
        let ts = &self.trees[&id];
        let l = &ts.legs[i].leg;
        ev.push(Event::SendToBroker(NativeOrder {
            ems_order_id: format!("{id}:{i}"),
            tenant_id: ts.tree.tenant_id.clone(),
            account_id: ts.tree.account_id.clone(),
            broker_id: ts.tree.broker_id.clone(),
            symbol: l.symbol.clone(),
            side: l.side,
            qty: l.qty - ts.legs[i].filled,
            price,
            native_type,
            tif: l.tif,
        }));
    }

    // ---------------- cancel ----------------
    fn cancel(&mut self, id: Uuid, leg: Option<usize>, ev: &mut Vec<Event>) {
        let Some(ts) = self.trees.get(&id) else { return };
        let idxs: Vec<usize> = match leg {
            Some(i) => vec![i],
            None => (0..ts.legs.len()).collect(),
        };
        for i in idxs {
            self.cancel_leg(id, i, ev);
        }
    }

    fn cancel_leg(&mut self, id: Uuid, i: usize, ev: &mut Vec<Event>) {
        let st = self.trees[&id].legs[i].status;
        if st.is_terminal() || st == Status::Cancelling {
            return;
        }
        if st.is_live_at_broker() {
            if let Some(bid) = self.trees[&id].legs[i].broker_order_id.clone() {
                self.transition(id, i, Status::Cancelling, None, ev);
                ev.push(Event::CancelAtBroker { ems_order_id: format!("{id}:{i}"), broker_order_id: bid });
                return; // BrokerCancelled gelince CANCELLED olur
            }
        }
        self.transition(id, i, Status::Cancelled, None, ev);
    }

    // ---------------- fill ----------------
    fn on_fill(&mut self, f: Fill, ev: &mut Vec<Event>) {
        let Some((id, i)) = self.lookup(&f.ems_order_id) else { return };
        {
            let ls = &mut self.trees.get_mut(&id).unwrap().legs[i];
            ls.filled += f.qty;
            if ls.broker_order_id.is_none() {
                ls.broker_order_id = Some(f.broker_order_id.clone());
            }
        }
        let (filled, qty) = {
            let ls = &self.trees[&id].legs[i];
            (ls.filled, ls.leg.qty)
        };
        let to = if f.remaining == Decimal::ZERO || filled >= qty { Status::Filled } else { Status::PartiallyFilled };
        self.transition(id, i, to, None, ev);
        self.last_price.insert(self.trees[&id].legs[i].leg.symbol.clone(), f.price);

        // OCO: aynı gruptaki kardeşleri iptal et
        let groups: Vec<Vec<usize>> = self.trees[&id].tree.oco_groups.clone();
        for g in groups.iter().filter(|g| g.contains(&i)) {
            for &j in g.iter().filter(|&&j| j != i) {
                self.cancel_leg(id, j, ev);
            }
        }

        // OTO / Chain / Bracket: child'ları aktive et
        let edges: Vec<Edge> = self.trees[&id].tree.tree.clone();
        for e in edges.iter().filter(|e| e.parent == i) {
            let ready = match e.on {
                TriggerOn::Filled => to == Status::Filled,
                TriggerOn::Partial => filled > Decimal::ZERO,
            };
            let child_status = self.trees[&id].legs[e.child].status;
            if ready && child_status == Status::PendingTrigger && self.trees[&id].legs[e.child].rule.is_none() {
                // child qty, parent'ın gerçekleşen miktarını aşamaz (stop qty = gerçek pozisyon)
                {
                    let ts = self.trees.get_mut(&id).unwrap();
                    let cq = ts.legs[e.child].leg.qty;
                    ts.legs[e.child].leg.qty = cq.min(filled);
                }
                self.activate(id, e.child, ev);
            }
        }
    }

    // ---------------- tick / trigger ----------------
    fn on_tick(&mut self, t: Tick, ev: &mut Vec<Event>) {
        self.last_price.insert(t.symbol.clone(), t.last);
        // Deterministik sıra: tree id'ye göre sıralı, sonra leg index
        let mut ids: Vec<Uuid> = self.trees.keys().copied().collect();
        ids.sort();
        for id in ids {
            let n = self.trees[&id].legs.len();
            for i in 0..n {
                let (matches, side) = {
                    let ls = &self.trees[&id].legs[i];
                    (ls.status == Status::PendingTrigger && ls.rule.is_some() && ls.leg.symbol == t.symbol, ls.leg.side)
                };
                if !matches {
                    continue;
                }
                let hit = self.trees.get_mut(&id).unwrap().legs[i].rule.as_mut().unwrap().evaluate(side, &t);
                if let Some(px) = hit {
                    let (price, nt) = {
                        let l = &self.trees[&id].legs[i].leg;
                        match l.native_type {
                            NativeType::Market => (None, NativeType::Market),
                            _ => (Some(l.price.unwrap_or(px)), NativeType::Limit),
                        }
                    };
                    // PendingTrigger → PendingRisk → Sending
                    self.transition(id, i, Status::PendingRisk, Some(format!("triggered @ {px}")), ev);
                    self.send(id, i, price, nt, ev);
                }
            }
        }
    }

    // ---------------- helpers ----------------
    fn lookup(&self, ems: &str) -> Option<(Uuid, usize)> {
        self.by_ems_id.get(ems).copied()
    }

    fn set_broker_id(&mut self, id: Uuid, i: usize, bid: String) {
        self.trees.get_mut(&id).unwrap().legs[i].broker_order_id = Some(bid);
    }

    fn transition(&mut self, id: Uuid, i: usize, to: Status, reason: Option<String>, ev: &mut Vec<Event>) {
        let ls = &mut self.trees.get_mut(&id).unwrap().legs[i];
        let from = ls.status;
        match from.transition(to) {
            Ok(s) => {
                ls.status = s;
                ev.push(Event::StateChanged { order_id: id, leg: i, from, to, reason });
            }
            Err(e) => {
                tracing::warn!(%id, leg = i, "{e}");
            }
        }
    }
}

// ======================= TESTS =======================
#[cfg(test)]
mod tests {
    use super::*;
    use rust_decimal_macros::dec;

    fn leg(sym: &str, side: Side, qty: Decimal, price: Option<Decimal>) -> Leg {
        Leg {
            symbol: sym.into(), side, qty, price,
            native_type: if price.is_some() { NativeType::Limit } else { NativeType::Market },
            tif: TimeInForce::Day, trigger_price: None, trail_amount: None, trail_percent: None, condition: None,
        }
    }

    /// Bracket: BUY 1000 @125 → TP SELL 1000 @130, SL SELL 1000 stop 121 (OCO)
    fn bracket() -> OrderTree {
        let mut sl = leg("GARAN", Side::Sell, dec!(1000), None);
        sl.trigger_price = Some(dec!(121));
        OrderTree {
            id: Uuid::new_v4(), tenant_id: "t1".into(), account_id: "a1".into(), broker_id: "mock".into(),
            legs: vec![leg("GARAN", Side::Buy, dec!(1000), Some(dec!(125))), leg("GARAN", Side::Sell, dec!(1000), Some(dec!(130))), sl],
            tree: vec![Edge { parent: 0, child: 1, on: TriggerOn::Filled }, Edge { parent: 0, child: 2, on: TriggerOn::Filled }],
            oco_groups: vec![vec![1, 2]],
            client_ref: None,
        }
    }

    fn sends(ev: &[Event]) -> Vec<&NativeOrder> {
        ev.iter().filter_map(|e| if let Event::SendToBroker(o) = e { Some(o) } else { None }).collect()
    }

    #[test]
    fn bracket_only_parent_goes_to_broker_first() {
        let mut e = Engine::default();
        let t = bracket();
        let id = t.id;
        let ev = e.apply(Command::Submit(t));
        let s = sends(&ev);
        assert_eq!(s.len(), 1);
        assert_eq!(s[0].ems_order_id, format!("{id}:0"));
        assert_eq!(e.tree(&id).unwrap().legs[1].status, Status::PendingTrigger);
        assert_eq!(e.tree(&id).unwrap().legs[2].status, Status::PendingTrigger);
    }

    #[test]
    fn parent_fill_activates_tp_and_arms_stop() {
        let mut e = Engine::default();
        let t = bracket();
        let id = t.id;
        e.apply(Command::Submit(t));
        e.apply(Command::BrokerAck { ems_order_id: format!("{id}:0"), broker_order_id: "B1".into() });
        let ev = e.apply(Command::BrokerFill(Fill {
            ems_order_id: format!("{id}:0"), broker_order_id: "B1".into(),
            qty: dec!(1000), price: dec!(125), remaining: dec!(0), ts_ms: 1,
        }));
        let s = sends(&ev);
        assert_eq!(s.len(), 1, "sadece TP borsaya gider, stop tetik bekler");
        assert_eq!(s[0].ems_order_id, format!("{id}:1"));
        let ts = e.tree(&id).unwrap();
        assert_eq!(ts.legs[0].status, Status::Filled);
        assert_eq!(ts.legs[1].status, Status::Sending);
        assert_eq!(ts.legs[2].status, Status::PendingTrigger);
        assert!(ts.legs[2].rule.is_some());
    }

    #[test]
    fn stop_triggers_on_tick_and_oco_cancels_tp() {
        let mut e = Engine::default();
        let t = bracket();
        let id = t.id;
        e.apply(Command::Submit(t));
        e.apply(Command::BrokerAck { ems_order_id: format!("{id}:0"), broker_order_id: "B1".into() });
        e.apply(Command::BrokerFill(Fill { ems_order_id: format!("{id}:0"), broker_order_id: "B1".into(), qty: dec!(1000), price: dec!(125), remaining: dec!(0), ts_ms: 1 }));
        e.apply(Command::BrokerAck { ems_order_id: format!("{id}:1"), broker_order_id: "B2".into() });

        // fiyat 121'e düşer → stop tetiklenir, MARKET olarak gider
        let ev = e.apply(Command::Tick(Tick { symbol: "GARAN".into(), last: dec!(120.9), bid: None, ask: None, ts_ms: 2 }));
        let s = sends(&ev);
        assert_eq!(s.len(), 1);
        assert_eq!(s[0].native_type, NativeType::Market);
        assert_eq!(s[0].ems_order_id, format!("{id}:2"));

        // stop dolar → OCO kardeş TP (B2) borsada iptal edilir
        e.apply(Command::BrokerAck { ems_order_id: format!("{id}:2"), broker_order_id: "B3".into() });
        let ev = e.apply(Command::BrokerFill(Fill { ems_order_id: format!("{id}:2"), broker_order_id: "B3".into(), qty: dec!(1000), price: dec!(120.9), remaining: dec!(0), ts_ms: 3 }));
        assert!(ev.iter().any(|x| matches!(x, Event::CancelAtBroker { broker_order_id, .. } if broker_order_id == "B2")));
        assert_eq!(e.tree(&id).unwrap().legs[1].status, Status::Cancelling);
        e.apply(Command::BrokerCancelled { ems_order_id: format!("{id}:1") });
        assert_eq!(e.tree(&id).unwrap().legs[1].status, Status::Cancelled);
    }

    #[test]
    fn partial_parent_fill_shrinks_child_qty() {
        let mut e = Engine::default();
        let mut t = bracket();
        t.tree[0].on = TriggerOn::Partial; // TP kısmi fill'de de aktive olsun
        let id = t.id;
        e.apply(Command::Submit(t));
        e.apply(Command::BrokerAck { ems_order_id: format!("{id}:0"), broker_order_id: "B1".into() });
        let ev = e.apply(Command::BrokerFill(Fill { ems_order_id: format!("{id}:0"), broker_order_id: "B1".into(), qty: dec!(400), price: dec!(125), remaining: dec!(600), ts_ms: 1 }));
        let s = sends(&ev);
        assert_eq!(s.len(), 1);
        assert_eq!(s[0].qty, dec!(400), "child qty parent'ın gerçekleşen 400'üne iner");
    }

    #[test]
    fn risk_rejects_and_emits_violation() {
        let mut e = Engine::new(Box::new(BasicRisk { max_qty: dec!(500) }));
        let t = bracket();
        let id = t.id;
        let ev = e.apply(Command::Submit(t));
        assert!(ev.iter().any(|x| matches!(x, Event::RiskViolation { rule, .. } if rule == "MAX_QTY")));
        assert_eq!(e.tree(&id).unwrap().legs[0].status, Status::Rejected);
        assert!(sends(&ev).is_empty());
    }

    #[test]
    fn invalid_tree_rejected() {
        let mut e = Engine::default();
        let mut t = bracket();
        t.tree.push(Edge { parent: 1, child: 0, on: TriggerOn::Filled }); // döngü
        let ev = e.apply(Command::Submit(t));
        assert!(matches!(ev[0], Event::Rejected { .. }));
    }

    #[test]
    fn trailing_stop_end_to_end() {
        let mut e = Engine::default();
        let mut sl = leg("THYAO", Side::Sell, dec!(100), None);
        sl.trail_amount = Some(dec!(2));
        sl.trigger_price = Some(dec!(300)); // referans
        let t = OrderTree { id: Uuid::new_v4(), tenant_id: "t".into(), account_id: "a".into(), broker_id: "mock".into(), legs: vec![sl], tree: vec![], oco_groups: vec![], client_ref: None };
        let id = t.id;
        assert!(sends(&e.apply(Command::Submit(t))).is_empty());
        let tk = |p: Decimal| Command::Tick(Tick { symbol: "THYAO".into(), last: p, bid: None, ask: None, ts_ms: 0 });
        assert!(sends(&e.apply(tk(dec!(305)))).is_empty()); // extreme 305
        assert!(sends(&e.apply(tk(dec!(304)))).is_empty());
        let ev = e.apply(tk(dec!(303))); // 305-2
        assert_eq!(sends(&ev).len(), 1);
        assert_eq!(e.tree(&id).unwrap().legs[0].status, Status::Sending);
    }
}
