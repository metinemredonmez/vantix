use crate::order::{Fill, NativeOrder, OrderTree, Tick};
use crate::state_machine::Status;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Motora giren komutlar (NATS: exec.order.*, exec.broker.*, md.tick.*)
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Command {
    Submit(OrderTree),
    Cancel { order_id: Uuid, leg: Option<usize> },
    BrokerAck { ems_order_id: String, broker_order_id: String },
    BrokerReject { ems_order_id: String, reason: String },
    BrokerFill(Fill),
    BrokerCancelled { ems_order_id: String },
    Tick(Tick),
}

/// Motordan çıkan olaylar (NATS: exec.order.state, exec.broker.send, exec.risk.violation)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Event {
    StateChanged {
        order_id: Uuid,
        leg: usize,
        from: Status,
        to: Status,
        reason: Option<String>,
    },
    SendToBroker(NativeOrder),
    CancelAtBroker {
        ems_order_id: String,
        broker_order_id: String,
    },
    RiskViolation {
        order_id: Uuid,
        leg: usize,
        rule: String,
        detail: String,
    },
    Rejected {
        order_id: Uuid,
        reason: String,
    },
}
