# exec-core — Vantix Execution Core (Rust)

Tek deterministik emir motoru. Fund (TEFAS) ve Trade (BIST/VİOP) modüllerinin her emri, tetiği ve tick'i buradan geçer.

## Tasarım
- `Engine` saf durum makinesidir: `apply(Command) -> Vec<Event>`; I/O yapmaz, tek task'ta sıralı çalışır → deterministik, replay edilebilir, test edilebilir.
- `OrderTree` = legs + tree (parent→child, FILLED/PARTIAL) + oco_groups. Bracket, chain, OCO, OTO, scale-out hepsi bu modelle ifade edilir.
- Trigger engine: STOP / TRAILING / CONDITIONAL leg'ler borsaya gitmez, tick ile tetiklenince native emre dönüşür.
- Risk: `RiskPolicy` trait'i — motor politika bilmez, dışarıdan verilir (tenant bazlı config sonra).
- `main.rs`: NATS subject'lerini `Command`'a çevirir, olayları `exec.*` subject'lerine yayınlar.

## Çalıştırma
```
cargo test                      # 12 test: state machine, trigger, bracket/OCO/partial/trailing/risk akışları
NATS_URL=nats://localhost:4222 RUST_LOG=info cargo run
```

## Örnek: bracket emri (exec.order.submit)
```json
{
  "tenant_id": "demo", "account_id": "acc1", "broker_id": "mock",
  "legs": [
    { "symbol": "GARAN", "side": "BUY",  "qty": "1000", "price": "125" },
    { "symbol": "GARAN", "side": "SELL", "qty": "1000", "price": "130" },
    { "symbol": "GARAN", "side": "SELL", "qty": "1000", "native_type": "MARKET", "trigger_price": "121" }
  ],
  "tree": [ { "parent": 0, "child": 1, "on": "FILLED" }, { "parent": 0, "child": 2, "on": "FILLED" } ],
  "oco_groups": [[1, 2]]
}
```
Akış: leg0 → `exec.broker.send`; fill gelince leg1 borsaya, leg2 tetik bekler; `md.tick.GARAN` last ≤ 121 → leg2 MARKET gider; dolunca leg1 için `exec.broker.cancel`.

## Sırada
persist (append-only order_event → Postgres) · JetStream replay on boot · algo slicer (TWAP/VWAP/iceberg) · sembol başına trigger index (O(1)) · pre-trade risk: bakiye/pozisyon/fat-finger
